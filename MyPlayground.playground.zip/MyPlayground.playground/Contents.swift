import UIKit

//var myVariable = 42
//myVariable = 50
//let apple = 3
//let oranges = 5
//let apples = "I have \(apple) apples"
//print(apples)
//
//
//


////explicitly declaring a variable
//let variable: Double = 70


//
////array and dictionaries
//var shopping = ["aa","bb","cc","dd"]
//print(shopping[0])
//var occupations = [ "Malcolm": "Captain", "Kaylee": "Mechanic",]
//print(occupations["Malcolm]"])
////add to dictionaries
//occupations["A"] = "added value"
//
//
////creating an empty array:
//let emptyarrayy = [String]()
//var emptydic = Dictionary<String,Float>()
//
//
////for loop
//let scores = [75,73,75,77]
//var teamscore = 0
//for ele in scores{
//    if ele > 50{
//        teamscore += 3
//    }
//    else{
//        teamscore += 1
//    }
//}
//
//
//print(teamscore)
//var df:String? = "First one"
//var greeting = ""
//var asd:String? = "Second one"
//
//if let name = df{
//    greeting = "Hello, \(name)"
//}
//if let name = asd{
//    greeting += String(name)
//}
//
//print(greeting)
//
//
//
////switch
//let vegetable = "red pepper"
//var vegetableComment = "1"
//switch vegetable {
//    case "celery":
//         vegetableComment = "Add some raisins and make ants on a log."
//    case "cucumber", "watercress":
//         vegetableComment = "That would make a good tea sandwhich"
//    case let x where x.hasSuffix("pepper"):
//         vegetableComment = "Is it a spicy \(x)"
//    default:
//         vegetableComment = "Everything tastes good in soup."
//}
//print(vegetableComment)




//// 3D dictionary/array
//var largest = 0;
//let interestingNumbers = [
//    "Prime": [2, 3, 5, 7, 11, 13],
//    "Fibonacci": [1, 1, 2, 3, 5, 8],
//    "Square": [1, 4, 9, 16, 25]]
//for(name,numbers)in interestingNumbers{
//    for number in numbers{
//        if (number > largest){
//            largest = number
//        }
//    }
//}
//print(largest)



////while loop
//var n = 0
//while n<5{
//    n += 2
//}




////for loop
//var count = 0
//for i in 0...3{
//    count+=i
//}
//print(count)




////function
//func function(inp1: String, inp2: String) ->String{
//    return "Hello \(inp1)\(inp2)"
//}
//print(function(inp1: "Robert", inp2: "Roebrt"))
////inp1 and inp2 required


////touple function
//func returntouple()->(Double,Double,Double){
//    return (3.3,3.3,3.3)
//}
//print(returntouple())




////accepting unlimited inputs
//func unlimitedSum(numbers: Int...)->Int{
//    var sum = 0;
//    for number in numbers{
//        sum += number;
//    }
//    return sum
//}
//print(unlimitedSum(numbers: 1,2,3,4,5))
////15



////nested functions: functions can access global variables
//func returnFifteen() -> Int {
//    var y = 10
//    func add() {
//        y += 5
//    }
//    add()
//    return y
//}
//print(returnFifteen())
////15




////You can also return another function, but you will have to indicate this in the return value part
//func returnfunction() -> (Int -> Int) {
//    func addOne(number: Int) -> Int {
//        return 1 + number }
//    return addOne }
//
//var increment = returnfunction()
//increment(7)

////Taking another function as its parameter
//func takefunction(list: [Int],condition: (Int->Bool))->Bool{
//
//}


////Creating a function without a name
//numbers.map({
//(number: Int) -> Int in
//    let result = 3 * number
//    return result
//})



////classes
class Shape{
    var surfaces = 0;
    func simpleDescription() -> String {
        return "A shape with \(surfaces) sides"
    }
}

var a = Shape()
print(a.simpleDescription())

